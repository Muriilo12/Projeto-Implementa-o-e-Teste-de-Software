import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.CalculadoraFrete;

public class CalculadoraFreteTest {

    CalculadoraFrete calculadora;

    @BeforeEach
    void preparar(){
        calculadora = new CalculadoraFrete();
    }

    @Test
    public void deveCobrarTest(){
        assertEquals(20.0, calculadora.calcular(100.00, false));
    }

    @Test
    public void naoDeveCobrarFreteTest(){
        assertEquals(0.0, calculadora.calcular(200, false));
    }

    @Test
    public void naoDeveCobrarFretePremiumTest(){
        assertEquals(0.0, calculadora.calcular(10, true));
    }

    @Test
    public void naoDevePagar30Test(){
        assertEquals(0.0, calculadora.calcular(30, false));
    }
    
}
